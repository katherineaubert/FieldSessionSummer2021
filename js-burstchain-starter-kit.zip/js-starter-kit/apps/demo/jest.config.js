module.exports = {
  name: 'demo',
  preset: '../../jest.config.js',
  coverageDirectory: '../../coverage/apps/demo'
};
