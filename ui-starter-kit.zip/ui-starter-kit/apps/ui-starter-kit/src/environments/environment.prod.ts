export const environment = {
  production: true,
  apiRoot: location.origin
};
